# Partner/Platform Logo Section — Implementation Notes

Asset specification: 900 × 300 PNG, transparent RGBA, centered on artboard, preserve object fit `contain`.

## Layout

- White background; no card backgrounds or borders.
- Heading centered above logo wall, responsive, use existing site's font.
- Desktop: seven evenly distributed columns, 140–180px item width, two rows when 14 logos are used; with 20 logos use three rows (7 + 7 + 6), or select just 14.
- Tablet: four columns. Mobile: two columns. Do not distort or crop logos.
- Use `object-fit: contain`, no CSS filter on the supplied PNGs; opacity is already in the file.
- Minimum clickable area when links are used: 44px high, but never link to a company unless relevant.

## Example (Next.js/React)

```tsx
const logos = [
  { name: 'Cloudflare', src: '/partners/01_WATERMARK_WORDMARK_STYLE/01_cloudflare.png' },
  { name: 'Amazon Web Services', src: '/partners/01_WATERMARK_WORDMARK_STYLE/02_amazon_web_services.png' },
  // Add selected verified and permitted items only.
];

export function PlatformLogoWall() {
  return (
    <section aria-labelledby="platform-heading" className="py-24 bg-white">
      <div className="mx-auto max-w-[1440px] px-6">
        <h2 id="platform-heading" className="text-center text-4xl tracking-tight">
          Platforms &amp; Technologies
        </h2>
        <div className="mt-24 grid grid-cols-2 gap-x-8 gap-y-16 md:grid-cols-4 xl:grid-cols-7 items-center">
          {logos.map((logo) => (
            <div key={logo.name} className="flex items-center justify-center h-[100px]">
              <img src={logo.src} alt={logo.name} className="w-full max-w-[180px] h-auto object-contain" loading="lazy" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

## Identity warning

These files are *not evidence of partnership*. Get official assets and brand-use approval before using partner/client claims.
