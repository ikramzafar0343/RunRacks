# Logo pack: hosting and technology brand marks

## Files

- `01_WATERMARK_WORDMARK_STYLE/` — 20 display-ready transparent PNGs (900 × 300 px), dark-gray at 65% opacity. **These are NON-OFFICIAL text lockups** using the locally available brand symbol plus a consistent Inter name label. Excellent for a coherent logo-wall visual, but not a substitute for a company's official corporate logo.
- `02_ORIGINAL_BRAND_SYMBOLS/` — 20 authentic **Font Awesome brand symbol glyphs** on transparent 900 × 300 px canvases in monochrome. These are licensed third-party vectors, NOT verified official corporate SVG downloads or primary wordmark artwork.
- `03_WATERMARK_BRAND_SYMBOLS/` — 20 matching semitransparent authentic symbol glyph PNGs, transparency preserved.
- `04_NAME_ONLY_REPLACEMENT_REQUIRED/` — Hostinger, MDMHost, GoDaddy, WaseerHost: **typography-only name placeholders, not official logos**. Their original images could not be downloaded/verified in this environment. Replace with permission-cleared official files before publication.
- `PREVIEW_20_LOGOS.jpg` — preview of the 20 watermark lockups.
- `BRAND_SOURCES.csv` — source details.
- `manifest.json` — filenames and structured metadata.
- `PARTNER_GRID_USAGE.md` — implementation guidance.

## Mandatory cautions for publishing

1. No relationship or authorization has been established with any listed brand. **Do not publish the collection as “Our Partners”, “Trusted By”, or “Clients” without independently verifying each association and securing appropriate permission to use the trademarks.** Safe category for generic illustration: `Platforms & Technologies` if genuinely relevant to the services.
2. Hostinger's and GoDaddy's own trademark policies limit usage of their logos; sourcing a PNG is not in itself a grant of permission. Always check the applicable brand guidelines.
3. Recoloring official corporate logos may conflict with logo guidelines. For exact corporate identity use an approved original asset *unaltered*, and apply any desired opacity/gray in CSS only if the policy permits it.
4. The supplied 20 marks were taken from the open Font Awesome Free brand-symbol distribution. These glyphs are licensed under CC BY 4.0; attribution and licenses appear below and in `LICENSE_NOTICES.txt`.
5. Files do not represent original company wordmarks. The two-row screenshot used primarily wordmark logos, so the watermark compositions are practical design illustrations only.

## Font Awesome source and attribution

Font Awesome Free 6.7.2 — Copyright Fonticons, Inc.
`https://fontawesome.com/license/free`
Brand icons: CC BY 4.0 (`https://creativecommons.org/licenses/by/4.0/`).
Attribution: 'Icons from Font Awesome Free by Fonticons, Inc., CC BY 4.0'.
Individual trademarks and brands remain the property of their respective owners.

## Missing brand logo sources to obtain

- Hostinger: https://www.hostinger.com/legal/brand-guidelines-permissions
- GoDaddy: https://www.godaddy.com/en/legal/agreements/brand-guidelines-and-permissions
- MDMHost: https://www.mdmhost.com/ (ask brand owner for official logo)
- WaseerHost: https://waseerhost.com/pk (ask brand owner for official logo)

If you supply those 4 original PNG/SVG files, the same normalization (transparent canvas, consistent visual size and watermark treatment) can be applied without guessing at the artwork.
